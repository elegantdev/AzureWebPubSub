import React, { useState } from "react";

import { Form, Input, Divider, Button, Checkbox } from 'antd';
import TextArea from "antd/lib/input/TextArea";

export const SendMesssage = (props) => {

    const onFinish = (values) => {
        //console.log('Success:', values);

        fetch('https://localhost:5001/api/v1/AzurePubSub', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(values),
        })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
            })
            .catch((error) => {
                console.error('Error:', error);
            });

    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    return (
        <>
            <Divider>Send message</Divider>
            <Form
                title=""
                name="basic"
                labelCol={{ span: 2 }}
                wrapperCol={{ span: 7 }}
                initialValues={{  }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
            >
                <Form.Item
                    label="Message"
                    name="message"
                    rules={[{ required: true, message: 'Please input your message!' }]}
                >
                    <TextArea rows={4} />
                </Form.Item>

                <Form.Item wrapperCol={{ offset: 7, span: 10 }}>
                    <Button type="primary" htmlType="submit">
                        Send
                    </Button>
                </Form.Item>
            </Form>
        </>
    );
}