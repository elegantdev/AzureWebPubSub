// == Azure WebPuSub
import { WebPubSubServiceClient, AzureKeyCredential } from '@azure/web-pubsub'
// == W3C sockets
import { w3cwebsocket as W3CWebSocket } from 'websocket'




// == Create the service client
const hubName = 'Hub';
const key = "E/QKZYo0iygWd2a+leRmu0FLI7DMps9Oqf/xjrV2GGo=";
const cred = new AzureKeyCredential(key);
const endpoint = "https://pubsubinital.webpubsub.azure.com";
const serviceClient = new WebPubSubServiceClient(endpoint, cred, hubName);

//console.log('Azure WebPubSub service client is', serviceClient);

/**
 * @summary Connect to the secure socket server thru the WebPubSub service
 */
 export async function connect (onError, onOpen, onMessage, onClose) {
    //console.log('About to get auth token…')

    //creating token which will be valid for 1 hour.
    let token = await serviceClient.getClientAccessToken()
    //console.log('Auth token is', token)
    
    // == Connect to the secured socket server          
    const url = token.url
    let wsClient = new W3CWebSocket(url, 'json.webpubsub.azure.v1')

    //console.log('Web socket is',wsClient)

    //Connect the callbacks
     onError =  wsClient.onerror 
     onOpen =   wsClient.onopen 
     onMessage =  wsClient.onmessage
     onClose = wsClient.onclose 
 }

