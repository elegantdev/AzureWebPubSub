import React, { Component } from 'react';

import { connect } from "./Services/azurewebpubsub";
import {  notification } from 'antd';
import NotifyMe from 'react-notification-timeline';
import { SendMesssage } from './components/sendmessage';



class App extends Component {

  constructor(props) {
    super(props);
    this.state = { notifications: [] };//notifications array initial
  }

  /**
   * @summary Antd notification configuration
   */
  openNotificationWithIcon = (type, message) => {
    notification[type]({
      message: 'Notifications',
      description: message,
      placement: 'bottomRight'
    });
  };

  /**
   * @summary Handle onmessage event of wss
   */
  onMessage = (message) => {
    let data = JSON.parse(message.data);
    if (data.data) {
      //update notfications in state array
      this.setState(state => ({
        notifications: state.notifications.concat({
          "update": data.data,
          "timestamp": new Date().getTime()
        })
      }));

      //show antd notfications
      this.openNotificationWithIcon('info', data.data);
    }
  }

  onOpen = (message) => {
    //console.log(message);
  }

  onClose = (message) => {
    //console.log(message);
  }
  onError = (message) => {
    //console.log(message);
  }
    //connect to webstream socket
  componentWillMount() {
    connect(this.onError, this.onOpen, this.onMessage, this.onClose);
  }

  render() {
    return (
      <>
        <div style={{ textAlign: 'right', padding: '2rem 2rem 2rem 2rem' }}>
          {/* display notifications  */}
          <NotifyMe
            data={this.state.notifications}
            storageKey='notific_key'
            notific_key='timestamp'
            notific_value='update'
            heading='Notification'
            sortedByKey={false}
            showDate={true}
            size={30}
            color="white"
          />

        </div>

        <div>
          {/* Ui to send notifications */}

          <SendMesssage></SendMesssage>
        </div>
      </>
    );
  }
}

export default App;